package com.example.egzamin_am;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView layoutWyswietlacz_text;
    Button layoutPasekDzialan_buttonPlus;
    Button layoutPasekDzialan_buttonMinus;
    Button layoutPasekDzialan_buttonMnozenie;
    Button layoutPasekDzialan_buttonDzielenie;
    Button tableLayoutKlawiatura_button1;
    Button tableLayoutKlawiatura_button2;
    Button tableLayoutKlawiatura_button3;
    Button tableLayoutKlawiatura_button4;
    Button tableLayoutKlawiatura_button5;
    Button tableLayoutKlawiatura_button6;
    Button tableLayoutKlawiatura_button7;
    Button tableLayoutKlawiatura_button8;
    Button tableLayoutKlawiatura_button9;
    Button tableLayoutKlawiatura_button0;
    Button buttonReset;
    String wyswietlaczTxtNewTxt;
    String wyswietlaczTxtOldTxt;
    String lastPick;
    boolean lastPicked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layoutWyswietlacz_text = (TextView) findViewById(R.id.layoutWyswietlacz_text);
        layoutPasekDzialan_buttonPlus = (Button) findViewById(R.id.layoutPasekDzialan_buttonPlus);
        layoutPasekDzialan_buttonMinus = (Button) findViewById(R.id.layoutPasekDzialan_buttonMinus);
        layoutPasekDzialan_buttonMnozenie = (Button) findViewById(R.id.layoutPasekDzialan_buttonMnozenie);
        layoutPasekDzialan_buttonDzielenie = (Button) findViewById(R.id.layoutPasekDzialan_buttonDzielenie);
        tableLayoutKlawiatura_button1 = (Button) findViewById(R.id.tableLayoutKlawiatura_button1);
        tableLayoutKlawiatura_button2 = (Button) findViewById(R.id.tableLayoutKlawiatura_button2);
        tableLayoutKlawiatura_button3 = (Button) findViewById(R.id.tableLayoutKlawiatura_button3);
        tableLayoutKlawiatura_button4 = (Button) findViewById(R.id.tableLayoutKlawiatura_button4);
        tableLayoutKlawiatura_button5 = (Button) findViewById(R.id.tableLayoutKlawiatura_button5);
        tableLayoutKlawiatura_button6 = (Button) findViewById(R.id.tableLayoutKlawiatura_button6);
        tableLayoutKlawiatura_button7 = (Button) findViewById(R.id.tableLayoutKlawiatura_button7);
        tableLayoutKlawiatura_button8 = (Button) findViewById(R.id.tableLayoutKlawiatura_button8);
        tableLayoutKlawiatura_button9 = (Button) findViewById(R.id.tableLayoutKlawiatura_button9);
        tableLayoutKlawiatura_button0 = (Button) findViewById(R.id.tableLayoutKlawiatura_button0);
        buttonReset = (Button) findViewById(R.id.buttonReset);
        wyswietlaczTxtOldTxt = layoutWyswietlacz_text.getText().toString();

        layoutPasekDzialan_buttonPlus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyswietlaczTxtNewTxt = layoutPasekDzialan_buttonPlus.getText().toString();

                if (lastPicked = true) {
                    layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt + wyswietlaczTxtNewTxt);
                } else {
                    wyswietlaczTxtOldTxt = layoutWyswietlacz_text.getText().toString() + wyswietlaczTxtNewTxt;
                    layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt);
                }

                lastPicked = true;
                lastPick = layoutPasekDzialan_buttonPlus.getText().toString();
            }
        });

        layoutPasekDzialan_buttonMinus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyswietlaczTxtNewTxt = layoutPasekDzialan_buttonMinus.getText().toString();

                if (lastPicked = true) {
                    layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt + wyswietlaczTxtNewTxt);
                } else {
                    wyswietlaczTxtOldTxt = layoutWyswietlacz_text.getText().toString() + wyswietlaczTxtNewTxt;
                    layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt);
                }

                lastPicked = true;
                lastPick = layoutPasekDzialan_buttonPlus.getText().toString();
            }
        });

        layoutPasekDzialan_buttonMnozenie.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyswietlaczTxtNewTxt = layoutPasekDzialan_buttonMnozenie.getText().toString();

                if (lastPicked = true) {
                    layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt + wyswietlaczTxtNewTxt);
                } else {
                    wyswietlaczTxtOldTxt = layoutWyswietlacz_text.getText().toString() + wyswietlaczTxtNewTxt;
                    layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt);
                }

                lastPicked = true;
                lastPick = layoutPasekDzialan_buttonPlus.getText().toString();
            }
        });

        layoutPasekDzialan_buttonDzielenie.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyswietlaczTxtNewTxt = layoutPasekDzialan_buttonDzielenie.getText().toString();

                if (lastPicked = true) {
                    layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt + wyswietlaczTxtNewTxt);
                } else {
                    wyswietlaczTxtOldTxt = layoutWyswietlacz_text.getText().toString() + wyswietlaczTxtNewTxt;
                    layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt);
                }

                lastPicked = true;
                lastPick = layoutPasekDzialan_buttonPlus.getText().toString();
            }
        });

        tableLayoutKlawiatura_button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyswietlaczTxtNewTxt = tableLayoutKlawiatura_button1.getText().toString();
                wyswietlaczTxtOldTxt = layoutWyswietlacz_text.getText().toString() + wyswietlaczTxtNewTxt;
                layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt);
                lastPicked = false;
            }
        });

        tableLayoutKlawiatura_button2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyswietlaczTxtNewTxt = tableLayoutKlawiatura_button2.getText().toString();
                wyswietlaczTxtOldTxt = layoutWyswietlacz_text.getText().toString() + wyswietlaczTxtNewTxt;
                layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt);
                lastPicked = false;
            }
        });

        tableLayoutKlawiatura_button3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyswietlaczTxtNewTxt = tableLayoutKlawiatura_button3.getText().toString();
                wyswietlaczTxtOldTxt = layoutWyswietlacz_text.getText().toString() + wyswietlaczTxtNewTxt;
                layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt);
                lastPicked = false;
            }
        });

        tableLayoutKlawiatura_button4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyswietlaczTxtNewTxt = tableLayoutKlawiatura_button4.getText().toString();
                wyswietlaczTxtOldTxt = layoutWyswietlacz_text.getText().toString() + wyswietlaczTxtNewTxt;
                layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt);
                lastPicked = false;
            }
        });

        tableLayoutKlawiatura_button5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyswietlaczTxtNewTxt = tableLayoutKlawiatura_button5.getText().toString();
                wyswietlaczTxtOldTxt = layoutWyswietlacz_text.getText().toString() + wyswietlaczTxtNewTxt;
                layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt);
                lastPicked = false;
            }
        });

        tableLayoutKlawiatura_button6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyswietlaczTxtNewTxt = tableLayoutKlawiatura_button6.getText().toString();
                wyswietlaczTxtOldTxt = layoutWyswietlacz_text.getText().toString() + wyswietlaczTxtNewTxt;
                layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt);
                lastPicked = false;
            }
        });

        tableLayoutKlawiatura_button7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyswietlaczTxtNewTxt = tableLayoutKlawiatura_button7.getText().toString();
                wyswietlaczTxtOldTxt = layoutWyswietlacz_text.getText().toString() + wyswietlaczTxtNewTxt;
                layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt);
                lastPicked = false;
            }
        });

        tableLayoutKlawiatura_button8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyswietlaczTxtNewTxt = tableLayoutKlawiatura_button8.getText().toString();
                wyswietlaczTxtOldTxt = layoutWyswietlacz_text.getText().toString() + wyswietlaczTxtNewTxt;
                layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt);
                lastPicked = false;
            }
        });

        tableLayoutKlawiatura_button9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyswietlaczTxtNewTxt = tableLayoutKlawiatura_button9.getText().toString();
                wyswietlaczTxtOldTxt = layoutWyswietlacz_text.getText().toString() + wyswietlaczTxtNewTxt;
                layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt);
                lastPicked = false;
            }
        });

        tableLayoutKlawiatura_button0.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyswietlaczTxtNewTxt = tableLayoutKlawiatura_button0.getText().toString();
                wyswietlaczTxtOldTxt = layoutWyswietlacz_text.getText().toString() + wyswietlaczTxtNewTxt;
                layoutWyswietlacz_text.setText(wyswietlaczTxtOldTxt);
                lastPicked = false;
            }
        });

        buttonReset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                layoutWyswietlacz_text.setText("");
                lastPicked = false;
            }
        });
    }
}